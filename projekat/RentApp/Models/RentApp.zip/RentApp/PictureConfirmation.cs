﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RentApp.Models.RentApp
{
    public class PictureConfirmation
    {
        public int Id { get; set; }
        public string PictureUrl { get; set; }
        public User User { get; set; }
    }
}