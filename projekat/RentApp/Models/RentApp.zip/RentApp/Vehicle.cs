﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RentApp.Models.RentApp
{
    public class Vehicle
    {
        public int Id { get; set; }
        public string Model { get; set; }
        public string Manufacturer { get; set; }
        public int? Year { get; set; }
        public string Pictureurl { get; set; }
        public string Description { get; set; }
        public Reservation Reservation { get; set; }

        public virtual Branch Branch { get; set; }
        public virtual VehicleType VehicleType { get; set; }
    }
}