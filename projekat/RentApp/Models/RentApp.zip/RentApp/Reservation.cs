﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RentApp.Models.RentApp
{
    public class Reservation
    {
        public int Id { get; set; }
        public DateTime? TimeStart { get; set; }
        public DateTime TimeEnd { get; set; }

        public virtual User User { get; set; }
        public virtual Vehicle Vehicle { get; set; }
        public virtual Branch BranchStart { get; set; }
        public virtual Branch BranchEnd { get; set; }
    }
}