﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RentApp.Models.RentApp
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Lastname { get; set; }
        public string Email { get; set; }
        public bool Finished { get; set; }
        public UserType Type { get; set; }
        public bool? ManagerCreationAllowed { get; set; }

        public virtual ICollection<PictureConfirmation> Pictures { get; set; }
        public virtual ICollection<Reservation> Reservations { get; set; }
        public virtual ICollection<Rating> Ratings { get; set; }
    }
}