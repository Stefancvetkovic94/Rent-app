﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RentApp.Models.RentApp
{
    public class Rating
    {
        public int Id { get; set; }
        public int Rated { get; set; }
        public string Comment { get; set; }
        public DateTime? Date { get; set; }
        public User User { get; set; }
        public Service Service { get; set; }
    }
}