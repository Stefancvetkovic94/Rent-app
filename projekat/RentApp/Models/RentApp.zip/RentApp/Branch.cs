﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RentApp.Models.RentApp
{
    public class Branch
    {
        public int Id { get; set; }
        public string Address { get; set; }
        public string PictureUrl { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public virtual Service Service { get; set; }

        public virtual ICollection<Reservation> ReservationsStart { get; set; }
        public virtual ICollection<Reservation> ReservationsEnd { get; set; }
        public virtual ICollection<Vehicle> Vehicles { get; set; }
    }
}